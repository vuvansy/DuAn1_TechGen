<?php
get_header();
?>
<main>
    <div class="success">
        <div class="content">
            <h1>ĐẶT HÀNG THÀNH CÔNG</h1>
            <strong>Chúc mừng bạn đã dặt hàng thành công đơn hàng của bạn sẽ đến tay bạn sớm nhất !</strong>

            <a href="?mod=order&action=cartview">Đến quản lý đơn hàng</a>

        </div>

    </div>
</main>

<?php
get_footer();
?>