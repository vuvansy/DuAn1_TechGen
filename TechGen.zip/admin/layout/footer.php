<!-- Footer  -->
<footer>
    <div class="copyright">
        <p>©2021 - 2024 Công Ty Cổ Phần Thương Mại - Dịch Vụ TechGen Copyright All 2023 By TechGen</p>
    </div>
</footer>
</body>

</html>