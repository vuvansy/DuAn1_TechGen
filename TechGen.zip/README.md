### DỰ ÁN 1

# NHÓM TECH GEN

## Folder libraries

# File database.php

-   Chứa các hàm thực hiện câu lệnh MySQL

*   Hàm kết nối dữ liệu
*   Thực thi chuỗi truy vấn
*   Lấy một dòng trong CSDL
*   Lấy một mảng trong CSDL
*   Lấy số bản ghi
*   Insert
*   Update
*   Delete
    # File validation.php
    -các hàm xử lý Validation form

## SỬ DỤNG ĐƠN VỊ REM CHO FONT CHỮ

h1 {
font-size: 2.4rem;
}

## CÀI ĐẶT BIẾN SỬ DỤNG BIẾN MÀU, FONT CHỮ

# Định nghĩa biến

:root {
--primary-color: #3498db;
--font-size: 16px;
}

# Sử dụng biến

.header {
background-color: var(--primary-color);
font-size: var(--font-size);
}
