  <!-- Slide  -->
  <div class="slide">
      <div class="container">
          <div class="slide__body">
              <img style="width: 100%;" id="hinh" src="public/images/slide/slide1.jpg" alt="">
              <i class="fa fa-chevron-circle-left" onclick="prev()"></i>
              <i class="fa fa-chevron-circle-right" onclick="next()"></i>
          </div>
      </div>
  </div>